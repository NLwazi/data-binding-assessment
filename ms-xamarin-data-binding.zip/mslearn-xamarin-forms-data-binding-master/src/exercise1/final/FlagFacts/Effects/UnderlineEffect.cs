﻿using Xamarin.Forms;

namespace FlagFacts.Effects
{
    public class UnderlineEffect : RoutingEffect
    {
        public UnderlineEffect() : base(typeof(UnderlineEffect).FullName)
        {
        }
    }
}
